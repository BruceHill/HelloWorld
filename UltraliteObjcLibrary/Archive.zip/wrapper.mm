//
//  wrapper.mm
//  Ultralite
//
//  Created by Bruce Hill on 2011/03/15.
//  Copyright 2011 Mobility at work. All rights reserved.
//

#import "wrapper.h"


@implementation wrapper

@end
